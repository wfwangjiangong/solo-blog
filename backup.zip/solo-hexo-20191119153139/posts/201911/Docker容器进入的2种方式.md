title: Docker容器进入的2种方式
date: '2019-11-14 16:13:01'
updated: '2019-11-14 17:28:32'
tags: [docker]
permalink: /articles/2019/11/14/1573719181862.html
---
　　在使用Docker创建了容器之后，大家比较关心的就是如何进入该容器了，其实进入Docker容器有好几多种方式，这里我们就讲一下常用的几种进入Docker容器的方法。  
  
　　进入Docker容器比较常见的几种做法如下：  
* 使用docker attach  
* 使用exec  

  
**一、使用docker attach进入Docker容器**

　　使用docker ps查看到该容器信息，然后使用docker attach进入该容器

        $ sudo docker ps 
        $ sudo docker attach 93ee25ecaba6 
  
　　但在，使用该命令有一个问题。当多个窗口同时使用该命令进入该容器时，所有的窗口都会同步显示。如果有一个窗口阻塞了，那么其他窗口也无法再进行操作。
　　因为这个原因，所以docker attach命令不太适合于生产环境，平时自己开发应用时可以使用该命令。

**二、使用docker exec进入Docker容器**

　　docker在1.3.X版本之后还提供了一个新的命令exec用于进入容器，这种方式相对更简单一些

        $ sudo docker ps  
        $ sudo docker exec -it 93ee25ecaba6 /bin/sh
