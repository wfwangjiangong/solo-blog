title: xcode-select切换Xcode
date: '2019-11-20 15:44:21'
updated: '2019-11-20 15:44:21'
tags: [Xcode]
permalink: /articles/2019/11/20/1574235861309.html
---
查看当前使用xcode版本路径
```
    xcode-select -p
```

查看xcode-select 版本
```
    xcode-select -v
```

重置xcode-select
```
    xcode-select -r
```

修改使用xcode版本路径
```
    sudo xcode-select -s /Applications/Xcode.app/Contents/Developer
```

查看其他更多的命令
```
    xcode-select -h
```

