title: macOS开启开发者模式
date: '2019-11-20 15:36:30'
updated: '2019-11-20 15:37:02'
tags: [macOS]
permalink: /articles/2019/11/20/1574235389915.html
---
终端输入 
```
    DevToolsSecurity -status
``` 
若提示
```
    Developer mode is currently enabled.
```
接着输入
```
    DevToolsSecurity -enable
``` 
提示
```
    Developer mode is already enabled.
```
